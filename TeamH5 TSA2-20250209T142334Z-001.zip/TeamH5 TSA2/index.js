document.addEventListener("DOMContentLoaded", function () {
    let introText = document.getElementById("intro-text");
    let introSection = document.getElementById("intro-section");
    let mainContent = document.getElementById("main-content");

    // Intro Text Animation
    introText.style.animation = "expandText 2s ease-in-out forwards";

    // Hide intro section and show main content after animation
    setTimeout(() => {
        introSection.style.animation = "fadeOut 1s ease-in-out forwards";
        setTimeout(() => {
            introSection.style.display = "none";
            mainContent.classList.remove("hidden");
        }, 1000);
    }, 2500); // Wait for expandText animation

    // Toggle Sidebar Menu
    document.getElementById("hamburger").addEventListener("click", function () {
        document.getElementById("sidebar").classList.toggle("active");
        this.classList.toggle("active");
    });
});