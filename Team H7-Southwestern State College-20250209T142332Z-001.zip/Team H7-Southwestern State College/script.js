

let builderLabel = document.getElementById("build");
if (builderLabel) {
    builderLabel.addEventListener("click", function(event) {
        event.preventDefault();
        let modal = document.getElementById("formModal");
        if (modal) {
            modal.style.display = "block";
        }
    });
}

window.onclick = function(event) {
    let modal = document.getElementById('formModal');
    if (modal && event.target == modal) {
        modal.style.display = "none";
    }
};

function previewImage(event, previewId) {
    var preview = document.getElementById(previewId);
    if (preview) {
        const file = event.target.files[0];
        if (file) {
            const objectURL = URL.createObjectURL(file);
            preview.src = objectURL;
            preview.style.display = "block";
        }
    }
}

let projectCount = 1;
function addProject() {
    projectCount++;
    let projectContainer = document.getElementById("projectsContainer");

    let newProject = document.createElement("div");
    newProject.classList.add("project-section");
    newProject.innerHTML = `
        <label>Project Title</label>
        <input type="text" id="projectTitle${projectCount}" placeholder="Enter project title" required>

        <label>Project Description</label>
        <textarea id="projectDesc${projectCount}" placeholder="Describe your project..." rows="3" required></textarea>

        <label>Upload Project Photo</label>
        <input type="file" id="projectPhoto${projectCount}" accept="image/*" required 
            onchange="previewImage(event, 'projectPreview${projectCount}')">
        <img id="projectPreview${projectCount}" class="preview-img" style="display: none;">
    `;

    projectContainer.appendChild(newProject);
}

emailjs.init("Js4OzQGKTQflfilqC");

